import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: []
})
/* const pfmeRoutes: Routes = [
   { path: 'home', component: HomeComponent}
]; */
export class PfmeRoutingModule {}
